package com.hari.autotasx;

import android.app.IntentService;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

/**
 * An {@link android.app.IntentService} subclass for handling asynchronous task requests in
 * a service on a separate handler thread.
 * <p/>
 */
public class AddCarParkService extends IntentService {


    public AddCarParkService() {
        super("AddCarParkService");
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        String ADD_DB = "AddCarParkService";
        Log.v(ADD_DB,"Inside service");
        if (intent != null) {
            final String action = intent.getAction();
            Log.v(ADD_DB, "updated");
            GeoFence geofence = new GeoFence();
            geofence.setNameLoc("CarParking");
            geofence.setRadius((float) 100);
            geofence.setRemmsg("You car is in and around 100 meters distance");

            Toast.makeText(this, "Inside Service", Toast.LENGTH_LONG).show();

            ManageDB dbinstance = new ManageDB(this);
            dbinstance.open();
            dbinstance.addCarPark(geofence);



        }
    }


}
