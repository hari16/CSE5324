package com.hari.autotasx;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

/**
 * Created by Meghana on 4/17/2015.
 */
public class WidgetCarParkProvider extends AppWidgetProvider{
    public static String REFRESH_ACTION = "com.example.android.weatherlistwidget.REFRESH";

    public void onReceive(Context ctx, Intent intent) {
                final String action = intent.getAction();
                if (action.equals(REFRESH_ACTION)) {
                        // send message to background service via startService here
                        // ..............
                     }
                 super.onReceive(ctx, intent);
            }
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
                 for (int i = 0; i < appWidgetIds.length; ++i) {
                        final RemoteViews rv = new RemoteViews(context.getPackageName(), R.layout.widget);
                     //   rv.setRemoteAdapter(appWidgetIds[i], R.id.widget_image, intent);

                        // Set the empty view to be displayed if the collection is empty.  It must be a sibling
                        // view of the collection view.
                        //rv.setEmptyView(R.id.weather_list, R.id.empty_view);
                                    // Bind the click intent for the refresh button on the widget
                        final Intent refreshIntent = new Intent(context, AddCarParkService.class);
                        refreshIntent.setAction(WidgetCarParkProvider.REFRESH_ACTION);
                        final PendingIntent refreshPendingIntent = PendingIntent.getBroadcast(context, 0,
                                refreshIntent, PendingIntent.FLAG_UPDATE_CURRENT);
                         rv.setOnClickPendingIntent(R.id.widget_image, refreshPendingIntent);
                                     appWidgetManager.updateAppWidget(appWidgetIds[i], rv);
                     }
                 super.onUpdate(context, appWidgetManager, appWidgetIds);
           }


}
